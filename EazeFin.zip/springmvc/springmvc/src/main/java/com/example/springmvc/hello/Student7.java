package com.example.springmvc.hello;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
@Component
public class Student7 {
	@Id
	private int aid;
	private String aname;
	private String acourse;

	public int getAid() {
		return aid;
	}

	public void setAid(int aid) {
		this.aid = aid;
	}

	public String getAname() {
		return aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}

	public String getAcourse() {
		return acourse;
	}

	public void setAcourse(String acourse) {
		this.acourse = acourse;
	}
	@Override
	public String toString() {
		return "Student [aid=" + aid + ", aname=" + aname + ", acourse=" + acourse + "]";
	}


}
