package com.example.springmvc.hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;




@Controller
public class HomeController {
	@Autowired
	private StudentRepo repo;
	
	@RequestMapping("/home")
	public String home() {
		System.out.println("Inside the home");
		return "index1";
	} 
	
	@RequestMapping("result")
	public String addStudent(Student7 student,ModelMap model) {
		model.addAttribute("student", student);
		repo.save(student);
		return "result";
}}
