package com.adminSettings.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.adminSettings.example.model.CompanyRegistration;

@Repository
public interface CompanyRegistrstionRepository extends JpaRepository<CompanyRegistration, Integer>{

	CompanyRegistration findById(int company_id);
	 @Query("SELECT c FROM CompanyRegistration c WHERE c.company_password = :current_password")//replace this with the company id from the session and change the query to retrieve the data based on the company id.
	    CompanyRegistration findUserByPassword(@Param("current_password") String password);
}
