package com.adminSettings.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adminSettings.example.model.Address;
import com.adminSettings.example.model.CompanyRegistration;
import com.adminSettings.example.repository.AddressRepository;
import com.adminSettings.example.repository.CompanyRegistrstionRepository;

import jakarta.transaction.Transactional;

@Service
public class AdminSettingsServiceImpl implements AdminSettingsService {

	@Autowired
	private CompanyRegistrstionRepository companyRegistrationRepository;

	@Autowired
	private AddressRepository addressRepository;

	@Override
	public CompanyRegistration getCompanyDetailsByCompanyId(int company_id) {
		return companyRegistrationRepository.findById(company_id);
	}

//	@Override
//	public Address getAddressByCompanyId(int company_id) {
//		CompanyRegistration companyRegistration = companyRegistrationRepository.findById(company_id);
//		if (companyRegistration != null) {
//			int addressId = companyRegistration.getAddress_id();
//			return addressRepository.findById(addressId).orElse(null);
//		}
//		return null;
//	}

	@Override
	public Address getAddressByCompanyId(int company_id) {
		CompanyRegistration companyRegistration = companyRegistrationRepository.findById(company_id);
		if (companyRegistration != null) {
			return companyRegistration.getAddress();
		}
		return null;
	}

	@Transactional
	@Override
	public int updateAdminSettings(CompanyRegistration companyRegistration, Address address) {
		companyRegistrationRepository.save(companyRegistration);
		addressRepository.save(address);
		return companyRegistration.getCompany_id();
	}

	@Override
	public int addPassword(String currentPassword, String newPassword){
		CompanyRegistration company = companyRegistrationRepository.findUserByPassword(currentPassword);
		if (company != null) {
			company.setCompany_password(newPassword);
			companyRegistrationRepository.save(company);
			return company.getCompany_id();
		}
		return 1;
	}
}
