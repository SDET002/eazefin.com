package com.adminSettings.example.dto;

import com.adminSettings.example.model.Address;
import com.adminSettings.example.model.CompanyRegistration;

public class CompanyDetailsDTO {
	
	private CompanyRegistration companyRegistration;
	private Address address;
	
	public CompanyRegistration getCompanyRegistration() {
		return companyRegistration;
	}
	public void setCompanyRegistration(CompanyRegistration companyRegistration) {
		this.companyRegistration = companyRegistration;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public CompanyDetailsDTO(CompanyRegistration companyRegistration, Address address) {
		super();
		this.companyRegistration = companyRegistration;
		this.address = address;
	}
	public CompanyDetailsDTO() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CompanyDetailsDTO [companyRegistration=" + companyRegistration + ", address=" + address + "]";
	}
	
}
