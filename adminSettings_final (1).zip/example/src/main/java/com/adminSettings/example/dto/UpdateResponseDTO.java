package com.adminSettings.example.dto;

public class UpdateResponseDTO {

	private String company_name;
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	private String company_phno;
	private String company_gst_in;
	private String company_description;
	private String address_name;
	private String address_post_office;
	private String address_city;
	private String address_district;
	private String address_state;
	private String address_country;
	private int address_zip;
	
	public String getCompany_phno() {
		return company_phno;
	}
	public void setCompany_phno(String company_phno) {
		this.company_phno = company_phno;
	}
	public String getCompany_gst_in() {
		return company_gst_in;
	}
	public void setCompany_gst_in(String company_gst_in) {
		this.company_gst_in = company_gst_in;
	}
	public String getCompany_description() {
		return company_description;
	}
	public void setCompany_description(String company_description) {
		this.company_description = company_description;
	}
	public String getAddress_name() {
		return address_name;
	}
	public void setAddress_name(String address_name) {
		this.address_name = address_name;
	}
	public String getAddress_post_office() {
		return address_post_office;
	}
	public void setAddress_post_office(String address_post_office) {
		this.address_post_office = address_post_office;
	}
	public String getAddress_city() {
		return address_city;
	}
	public void setAddress_city(String address_city) {
		this.address_city = address_city;
	}
	public String getAddress_district() {
		return address_district;
	}
	public void setAddress_district(String address_district) {
		this.address_district = address_district;
	}
	public String getAddress_state() {
		return address_state;
	}
	public void setAddress_state(String address_state) {
		this.address_state = address_state;
	}
	public String getAddress_country() {
		return address_country;
	}
	public void setAddress_country(String address_country) {
		this.address_country = address_country;
	}
	public int getAddress_zip() {
		return address_zip;
	}
	public void setAddress_zip(int address_zip) {
		this.address_zip = address_zip;
	}
	
	public UpdateResponseDTO(String company_phno, String company_gst_in, String company_description,
			String address_name, String address_post_office, String address_city, String address_district,
			String address_state, String address_country, int address_zip) {
		super();
		this.company_phno = company_phno;
		this.company_gst_in = company_gst_in;
		this.company_description = company_description;
		this.address_name = address_name;
		this.address_post_office = address_post_office;
		this.address_city = address_city;
		this.address_district = address_district;
		this.address_state = address_state;
		this.address_country = address_country;
		this.address_zip = address_zip;
	}
}
