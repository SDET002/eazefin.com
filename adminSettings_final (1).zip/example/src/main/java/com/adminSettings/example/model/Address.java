package com.adminSettings.example.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_address")
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int address_id;
	
	@Column(name = "address_name")
	private String address_name;
	
	@Column(name = "address_post_office")
	private String address_post_office;
	
	@Column(name = "address_city")
	private String address_city;
	
	@Column(name = "address_district")
	private String address_district;
	
	@Column(name = "address_state")
	private String address_state;
	
	@Column(name = "address_country")
	private String address_country;
	
	@Column(name = "address_zip")
	private int address_zip;

	public int getAddress_id() {
		return address_id;
	}

	public void setAddress_id(int address_id) {
		this.address_id = address_id;
	}

	public String getAddress_name() {
		return address_name;
	}

	public void setAddress_name(String address_name) {
		this.address_name = address_name;
	}

	public String getAddress_post_office() {
		return address_post_office;
	}

	public void setAddress_post_office(String address_post_office) {
		this.address_post_office = address_post_office;
	}

	public String getAddress_city() {
		return address_city;
	}

	public void setAddress_city(String address_city) {
		this.address_city = address_city;
	}

	public String getAddress_district() {
		return address_district;
	}

	public void setAddress_district(String address_district) {
		this.address_district = address_district;
	}

	public String getAddress_state() {
		return address_state;
	}

	public void setAddress_state(String address_state) {
		this.address_state = address_state;
	}

	public String getAddress_country() {
		return address_country;
	}

	public void setAddress_country(String address_country) {
		this.address_country = address_country;
	}

	public int getAddress_zip() {
		return address_zip;
	}

	public void setAddress_zip(int address_zip) {
		this.address_zip = address_zip;
	}
	
}