package com.adminSettings.example.service;

import com.adminSettings.example.model.Address;
import com.adminSettings.example.model.CompanyRegistration;

public interface AdminSettingsService {
	public CompanyRegistration getCompanyDetailsByCompanyId(int company_id);
	public Address getAddressByCompanyId(int company_id);
	public int updateAdminSettings(CompanyRegistration companyRegistration, Address address);
	public int addPassword(String currentPassword, String newPassword);
}
