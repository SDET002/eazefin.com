package com.adminSettings.example.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_company_registration")
public class CompanyRegistration {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int company_id;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "address_id", referencedColumnName = "address_id")
	private Address address;
	
//	@Column(name = "address_id")
//	private int address_id;
	
	@Column(name = "company_name")
	private String company_name;
	
	@Column(name = "company_password")
	private String company_password;

	@Column(name = "company_phno")
	private String company_phno;

	@Column(name = "company_gst_in")
	private String company_gst_in;
	
	@Column(name = "company_description")
	private String company_description;

	
	public int getCompany_id() {
		return company_id;
	}

	public void setCompany_id(int company_id) {
		this.company_id = company_id;
	}

//	public int getAddress_id() {
//		return address_id;
//	}
//
//	public void setAddress_id(int address_id) {
//		this.address_id = address_id;
//	}

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public String getCompany_phno() {
		return company_phno;
	}

	public void setCompany_phno(String company_phno) {
		this.company_phno = company_phno;
	}
	
	public String getCompany_gst_in() {
		return company_gst_in;
	}

	public void setCompany_gst_in(String company_gst_in) {
		this.company_gst_in = company_gst_in;
	}

	public String getCompany_description() {
		return company_description;
	}

	public void setCompany_description(String company_description) {
		this.company_description = company_description;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	public String getCompany_password() {
		return company_password;
	}

	public void setCompany_password(String company_password) {
		this.company_password = company_password;
	}
	
	@Override
	public String toString() {
		return "CompanyRegistration [company_id=" + company_id  + ", company_name="
				+ company_name + ", company_phno=" + company_phno + ", company_gst_in=" + company_gst_in
				+ ", company_description=" + company_description + "]";
	}
	
}