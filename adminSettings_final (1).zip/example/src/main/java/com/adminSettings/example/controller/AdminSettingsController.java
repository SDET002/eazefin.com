package com.adminSettings.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.adminSettings.example.model.Address;
import com.adminSettings.example.model.CompanyRegistration;
import com.adminSettings.example.service.AdminSettingsService;

@Controller
public class AdminSettingsController {

	@Autowired
	private AdminSettingsService adminSettingsService;

	@GetMapping("/company-details/{company_id}")//get the company_id form the session
	public String getCompanyDetails(@PathVariable int company_id, Model model) {
		CompanyRegistration companyRegistration = adminSettingsService.getCompanyDetailsByCompanyId(company_id);
		Address address = adminSettingsService.getAddressByCompanyId(company_id);
		model.addAttribute("companyRegistration", companyRegistration);
		model.addAttribute("address", address);
		return "settingsAdmin";
	}

//	@PostMapping("/updateSettings")
//	public String updateSetitngs(@ModelAttribute("companyRegistration") CompanyRegistration companyRegistration, @ModelAttribute("address") Address address) {
//		adminSettingsService.updateAdminSettings(companyRegistration, address);
//		return "settingsAdmin";
//	}

	@PutMapping("/updateSettings")
	public String updateSetitngs(@ModelAttribute("companyRegistration") CompanyRegistration companyRegistration,
			@ModelAttribute("address") Address address) {
		int companyId = adminSettingsService.updateAdminSettings(companyRegistration, address);
		return "redirect:/company-details/" + companyId;
	}

//	@PutMapping("/addPassword")
//	public String addPassword(@RequestParam String current_password, @RequestParam String new_password,
//			@RequestParam String confirm_password, RedirectAttributes redirectAttributes) {
//		int companyId = 0;//replace this with the company id in the session
//		try {
//			companyId = adminSettingsService.addPassword(current_password, new_password, confirm_password);
//		} catch (Exception e) { 
//			redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
//		}
//		return "redirect:/company-details/" + companyId;
//	} 
	
	@PutMapping("/addPassword")
	public String addPassword(@RequestParam String current_password, @RequestParam String new_password) {
	    int companyId = adminSettingsService.addPassword(current_password, new_password);
	    if(companyId==1) {
	    	return "redirect:/error?message=Current Password do not match";
	    }
	    return "redirect:/company-details/" + companyId;
	}	
}