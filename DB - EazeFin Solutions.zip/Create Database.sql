-- Create Database 

CREATE DATABASE IF NOT EXISTS EazeFin;
 
USE EazeFin;