package com.example.springmvc.Login;

import org.springframework.stereotype.Service;

@Service
public class AuthenticationService {
	
	public boolean authenticate(String name,String password) {
		boolean name1=name.equalsIgnoreCase("Nagasarla Kiran");
		boolean password1=name.equalsIgnoreCase("Kiran@1234");
		return name1 && password1;
	}
	

}
