package com.example.springmvc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springmvc.entity.CompanyRegistration;

public interface EazefinRepository extends JpaRepository<CompanyRegistration, Integer>{
	

}
