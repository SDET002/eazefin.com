package com.example.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DashboardController {
	
	@RequestMapping("/companydashboard")
	public String gotoCompanyDashboard(ModelMap model)
	{
		return "comdashboard";
	}

}
