package com.example.springmvc.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_company_registration")
public class CompanyRegistration {
	
	@Id
	private int company_id ;
	@Column
	private int address_id ; 
	@Column
	private String company_name ;
	@Column
	private String company_gst_in ;
	@Column
	private LocalDate company_registration_year ;
	@Column
	private LocalDateTime company_register_timestamp ; 
	@Column
	private String company_username  ;
	@Column
	private String company_password_hash;
	@Column
	private String company_description  ;
	@Column
	private boolean company_active_status;
	
	public int getCompany_id() {
		return company_id;
	}
	public void setCompany_id(int company_id) {
		this.company_id = company_id;
	}
	public int getAddress_id() {
		return address_id;
	}
	public void setAddress_id(int address_id) {
		this.address_id = address_id;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getCompany_gst_in() {
		return company_gst_in;
	}
	public void setCompany_gst_in(String company_gst_in) {
		this.company_gst_in = company_gst_in;
	}
	public LocalDate getCompany_registration_year() {
		return company_registration_year;
	}
	public void setCompany_registration_year(LocalDate company_registration_year) {
		this.company_registration_year = company_registration_year;
	}
	public LocalDateTime getCompany_register_timestamp() {
		return company_register_timestamp;
	}
	public void setCompany_register_timestamp(LocalDateTime company_register_timestamp) {
		this.company_register_timestamp = company_register_timestamp;
	}
	public String getCompany_username() {
		return company_username;
	}
	public void setCompany_username(String company_username) {
		this.company_username = company_username;
	}
	public String getCompany_password_hash() {
		return company_password_hash;
	}
	public void setCompany_password_hash(String company_password_hash) {
		this.company_password_hash = company_password_hash;
	}
	public String getCompany_description() {
		return company_description;
	}
	public void setCompany_description(String company_description) {
		this.company_description = company_description;
	}
	public boolean isCompany_active_status() {
		return company_active_status;
	}
	public void setCompany_active_status(boolean company_active_status) {
		this.company_active_status = company_active_status;
	}
	@Override
	public String toString() {
		return "CompanyRegistration [company_id=" + company_id + ", address_id=" + address_id + ", company_name="
				+ company_name + ", company_gst_in=" + company_gst_in + ", company_registration_year="
				+ company_registration_year + ", company_register_timestamp=" + company_register_timestamp
				+ ", company_username=" + company_username + ", company_password_hash=" + company_password_hash
				+ ", company_description=" + company_description + ", company_active_status=" + company_active_status
				+ "]";
	}
	public CompanyRegistration(int company_id, int address_id, String company_name, String company_gst_in,
			LocalDate company_registration_year, LocalDateTime company_register_timestamp, String company_username,
			String company_password_hash, String company_description, boolean company_active_status) {
		super();
		this.company_id = company_id;
		this.address_id = address_id;
		this.company_name = company_name;
		this.company_gst_in = company_gst_in;
		this.company_registration_year = company_registration_year;
		this.company_register_timestamp = company_register_timestamp;
		this.company_username = company_username;
		this.company_password_hash = company_password_hash;
		this.company_description = company_description;
		this.company_active_status = company_active_status;
	}
	public CompanyRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
