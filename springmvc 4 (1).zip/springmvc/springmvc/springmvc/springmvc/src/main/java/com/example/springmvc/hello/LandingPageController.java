package com.example.springmvc.hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@Controller
public class LandingPageController {
	
	@Autowired
	private RegistrationRepository repo;
	
	@RequestMapping("/home1")
	public String landingPage() {
		return "LandingPage";
	}
	
	
	@RequestMapping("/Companyregistration.html")
	public String companyRgPg( ) {
		
		return "Companyregistration";
	}
	
	
	@RequestMapping("/Login")
	public String Login(CompanyRegistration companyreg,ModelMap model) {
		
//		model.addAttribute("result", companyreg);
//		repo.save(companyreg);
		return "index";
	}
	
	@RequestMapping("/companydashboard")
	public String gotoCompanyDashboard(ModelMap model)
	{
		
		//model.put("name", company_name);
		return "comdashboard";
	}
	

}
