package com.example.springmvc.Login;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {
	
	
	private AuthenticationService authenticat;
	
	public LoginController(AuthenticationService authenticat) {
		super();
		this.authenticat = authenticat;
	}

	@RequestMapping(value="login",method=RequestMethod.GET)
	public String login() {
		//model.put("name", name);
		return "login";
	}
	
	/*@RequestMapping(value="login",method=RequestMethod.POST)
	public String register(@RequestParam String Name,@RequestParam String Password,ModelMap model) {
		model.put("Name", Name);
		model.put("Password", Password);
		return "register";     
	}*/
	
	@RequestMapping(value="login",method=RequestMethod.POST)
	public String register(@RequestParam String name,@RequestParam String password, ModelMap model) {
		
       if( authenticat.authenticate(name,password)) {
		model.put("name1", name);
		return "register";   
       }
       else {
       model.put("errormessage", "Invalid crendentials");
       return "login";
       }
}
	

}
