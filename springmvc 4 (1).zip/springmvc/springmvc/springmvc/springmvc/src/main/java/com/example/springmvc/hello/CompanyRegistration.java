package com.example.springmvc.hello;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Component
@Entity
public class CompanyRegistration {
	
	
	private String Company_Name;
	public String getCompany_Name() {
		return Company_Name;
	}
	public void setCompany_Name(String company_Name) {
		Company_Name = company_Name;
	}
	public String getOwner_name() {
		return Owner_name;
	}
	public void setOwner_name(String owner_name) {
		Owner_name = owner_name;
	}
	@Id
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getEmail_address() {
		return email_address;
	}
	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirm_password() {
		return confirm_password;
	}
	public void setConfirm_password(String confirm_password) {
		this.confirm_password = confirm_password;
	}
	public String getGSTNO() {
		return GSTNO;
	}
	public void setGSTNO(String gSTNO) {
		GSTNO = gSTNO;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	private String Owner_name;
	private long phone;
	private String email_address;
	private String password;
	private String confirm_password;
	private String GSTNO;
	private String address;
	private String description;
	public CompanyRegistration(String company_Name, String owner_name, long phone, String email_address,
			String password, String confirm_password, String gSTNO, String address, String description) {
		super();
		Company_Name = company_Name;
		Owner_name = owner_name;
		this.phone = phone;
		this.email_address = email_address;
		this.password = password;
		this.confirm_password = confirm_password;
		GSTNO = gSTNO;
		this.address = address;
		this.description = description;
	}
	
	public CompanyRegistration() {
		
	}
	
	

}
