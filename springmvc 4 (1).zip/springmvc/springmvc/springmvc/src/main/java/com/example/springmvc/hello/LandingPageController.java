package com.example.springmvc.hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.springmvc.repository.EazefinRepository;
import com.example.springmvc.service.CompanyService;


@Controller
public class LandingPageController {
	
	@Autowired
	private RegistrationRepository repo;
	
	 @Autowired
	    private CompanyService companyService;
	
	
	@RequestMapping("/home1")
	public String landingPage() {
		return "LandingPage";
	}
	
	
	@RequestMapping("/Companyregistration.html")
	public String companyRgPg( ) {
		
		return "Companyregistration";
	}
	
	
	@RequestMapping("/Login")
	public String Login(CompanyRegistration companyreg,ModelMap model) {
		
//		model.addAttribute("result", companyreg);
//		repo.save(companyreg);
		return "index";
	}
	
	@RequestMapping("/companydashboard")
	public String gotoCompanyDashboard(ModelMap model)
	{
//		String company_name=eazefinrepo.findCompanyName();
//		model.addAttribute("company_name", company_name);
		
		//model.put("name", company_name);
		return "comdashboard";
	}

	
	@Autowired
    public LandingPageController(CompanyService companyService) {
        this.companyService = companyService;
    }

    @GetMapping("/comdashboard")
    public String showCompanyDashboard(Model model) {
        // Fetch company details for ID 2
    	com.example.springmvc.entity.CompanyRegistration companyDetails = companyService.getCompanyDetailsById(2L);
        model.addAttribute("company", companyDetails);
        return "comdashboard"; // Return the name of your view template
    }
}
