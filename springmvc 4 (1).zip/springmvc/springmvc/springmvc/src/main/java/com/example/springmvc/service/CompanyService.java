package com.example.springmvc.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.springmvc.entity.CompanyRegistration;
import com.example.springmvc.repository.EazefinRepository;

public class CompanyService {
	
	
	
	private final EazefinRepository eazefinrepo;
	
	   @Autowired
	    public CompanyService(EazefinRepository eazefinrepo) {
	        this.eazefinrepo = eazefinrepo;
	    }
	
	   

	 

//    @Autowired
//    public CompanyService(CompanyRepository companyRepository) {
//        this.companyRepository = companyRepository;
//    }

    public CompanyRegistration getCompanyDetailsById(long id) {
        // Fetch company details for ID 2
        return eazefinrepo.findById(2L);
    }

}
