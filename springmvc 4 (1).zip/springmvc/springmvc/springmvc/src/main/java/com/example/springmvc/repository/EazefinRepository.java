package com.example.springmvc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;

import com.example.springmvc.entity.CompanyRegistration;

public interface EazefinRepository extends JpaRepository<CompanyRegistration, Integer>{
	
//	@Query("Select company_name from tbl_company_registration where company_id=1")
//		String findCompanyName();
	
	CompanyRegistration findById(Long id);
}
