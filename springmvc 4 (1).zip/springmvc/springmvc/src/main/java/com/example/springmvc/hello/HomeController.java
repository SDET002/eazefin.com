package com.example.springmvc.hello;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.springmvc.hello.entity.Address;
import com.example.springmvc.hello.entity.Employee;
import com.example.springmvc.hello.repository.AddressRepository;
import com.example.springmvc.hello.repository.EmployeeRepository;
import com.example.springmvc.hello.service.EmployeeService;




@Controller
public class HomeController {
	@Autowired
	private StudentRepo repo;
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private AddressRepository  addressRepository;
	
	@Autowired
	private EmployeeService empService;

	@RequestMapping("viewEmployee")
	public String gotoViewEmployee(Model model)
	{
		List<Employee> emps = empService.getAllEmployees();
		model.addAttribute("emps",emps);
		return "viewEmp";
	}


		@RequestMapping("view-details")
		public String moreDetails(@RequestParam("id") int id, Model model)
		{
			Employee employee = empService.getEmployeeById(id);
			model.addAttribute("employee",employee);
			return "moredetails";
		}
	
		
		
		
		
		
		
	@RequestMapping("/home")
	public String home() {
		System.out.println("Inside the home");
		return "index1";
	} 
	
	@RequestMapping("result")
	public String addStudent(Student7 student,ModelMap model) {
		model.addAttribute("student", student);
		repo.save(student);
		return "result";
}
	
	
	
	
	
	
	
	@RequestMapping("addEmployee")
	public String gotoViewEmployee()
	{
		return "employee";
	}
	

	
	@PostMapping("/register")
    public String processRegistrationForm(@ModelAttribute Employee employee,@ModelAttribute Address address) {

		 
		 Address savedAddress = addressRepository.save(address);
		 employee.setAddress(savedAddress);

     
          Employee save = employeeRepository.save(employee);

 
        return "redirect:/viewEmployee"; 
    }
	}
