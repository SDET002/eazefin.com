package com.example.springmvc.hello.service;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.example.springmvc.hello.entity.Employee;
import com.example.springmvc.hello.repository.AddressRepository;
//import com.example.springmvc.hello.entity.Company;
import com.example.springmvc.hello.repository.EmployeeRepository;
 
@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository emprepo;
	
	@Autowired
	private AddressRepository addrepo;
 
	public List<Employee> getAllEmployees()
	 {
		 return emprepo.findAll().stream().collect(Collectors.toList());
	 }
	 public Employee getEmployeeById(int id)
	 {
		 return emprepo.findById(id).orElse(null);
	 }

	 public Employee getEmployeeByAddressId(int id)
	 {
		 return emprepo.findById(id).orElse(null);
	 }

 
}