package com.example.springmvc.hello.entity;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Value;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_employee")
public class Employee {
	


	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int employee_id;


	@Column
	@Value("2")
	private int company_id ;
	
	
	 @OneToOne(fetch = FetchType.LAZY, optional = false)
	 @JoinColumn(name = "user_address_id", nullable = false)
	 private Address address;

	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}

	@Column
	private LocalDate employee_date_of_birth ; 
	@Column
	private int employee_age ; 
	@Column
	private int employee_aadhaar_number ;
	@Column
	private int employee_emp_id ; 
	@Column
	private double employee_salary ; 
	@Column
	private LocalDate employee_joined_date ;
	@Column
	private String employee_first_name ; 
	@Column
	private String employee_middle_name ; 
	@Column
	private String employee_last_name ; 
	@Column
	private String employee_email ; 
	@Column
	private int employee_primary_contact ;
	@Column
	private int employee_secondary_contact ;
	@Column
	private String employee_password_hash ;
	@Column
	private boolean employee_active_status;
	@Column
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public int getCompany_id() {
		return company_id;
	}
	public void setCompany_id(int company_id) {
		this.company_id = company_id;
	}
//	public int getUser_address_id() {
//		return user_address_id;
//	}
//	public void setUser_address_id(int user_address_id) {
//		this.user_address_id = user_address_id;
//	}
	public LocalDate getEmployee_date_of_birth() {
		return employee_date_of_birth;
	}
	public void setEmployee_date_of_birth(LocalDate employee_date_of_birth) {
		this.employee_date_of_birth = employee_date_of_birth;
	}
	public int getEmployee_age() {
		return employee_age;
	}
	public void setEmployee_age(int employee_age) {
		this.employee_age = employee_age;
	}
	public int getEmployee_aadhaar_number() {
		return employee_aadhaar_number;
	}
	public void setEmployee_aadhaar_number(int employee_aadhaar_number) {
		this.employee_aadhaar_number = employee_aadhaar_number;
	}
	public int getEmployee_emp_id() {
		return employee_emp_id;
	}
	public void setEmployee_emp_id(int employee_emp_id) {
		this.employee_emp_id = employee_emp_id;
	}
	public double getEmployee_salary() {
		return employee_salary;
	}
	public void setEmployee_salary(double employee_salary) {
		this.employee_salary = employee_salary;
	}
	public LocalDate getEmployee_joined_date() {
		return employee_joined_date;
	}
	public void setEmployee_joined_date(LocalDate employee_joined_date) {
		this.employee_joined_date = employee_joined_date;
	}
	public String getEmployee_first_name() {
		return employee_first_name;
	}
	public void setEmployee_first_name(String employee_first_name) {
		this.employee_first_name = employee_first_name;
	}
	public String getEmployee_middle_name() {
		return employee_middle_name;
	}
	public void setEmployee_middle_name(String employee_middle_name) {
		this.employee_middle_name = employee_middle_name;
	}
	public String getEmployee_last_name() {
		return employee_last_name;
	}
	public void setEmployee_last_name(String employee_last_name) {
		this.employee_last_name = employee_last_name;
	}
	public String getEmployee_email() {
		return employee_email;
	}
	public void setEmployee_email(String employee_email) {
		this.employee_email = employee_email;
	}
	public int getEmployee_primary_contact() {
		return employee_primary_contact;
	}
	public void setEmployee_primary_contact(int employee_primary_contact) {
		this.employee_primary_contact = employee_primary_contact;
	}
	public int getEmployee_secondary_contact() {
		return employee_secondary_contact;
	}
	public void setEmployee_secondary_contact(int employee_secondary_contact) {
		this.employee_secondary_contact = employee_secondary_contact;
	}
	public String getEmployee_password_hash() {
		return employee_password_hash;
	}
	public void setEmployee_password_hash(String employee_password_hash) {
		this.employee_password_hash = employee_password_hash;
	}
	public boolean isEmployee_active_status() {
		return employee_active_status;
	}
	public void setEmployee_active_status(boolean employee_active_status) {
		this.employee_active_status = employee_active_status;
	}
	
	public Employee()
	{
		super();
	}
	@Override
	public String toString() {
		return "Employee [employee_id=" + employee_id + ", company_id=" + company_id + ", address=" + address
				+ ", employee_date_of_birth=" + employee_date_of_birth + ", employee_age=" + employee_age
				+ ", employee_aadhaar_number=" + employee_aadhaar_number + ", employee_emp_id=" + employee_emp_id
				+ ", employee_salary=" + employee_salary + ", employee_joined_date=" + employee_joined_date
				+ ", employee_first_name=" + employee_first_name + ", employee_middle_name=" + employee_middle_name
				+ ", employee_last_name=" + employee_last_name + ", employee_email=" + employee_email
				+ ", employee_primary_contact=" + employee_primary_contact + ", employee_secondary_contact="
				+ employee_secondary_contact + ", employee_password_hash=" + employee_password_hash
				+ ", employee_active_status=" + employee_active_status + "]";
	}
	public Employee(int employee_id, int company_id, Address address, LocalDate employee_date_of_birth,
			int employee_age, int employee_aadhaar_number, int employee_emp_id, double employee_salary,
			LocalDate employee_joined_date, String employee_first_name, String employee_middle_name,
			String employee_last_name, String employee_email, int employee_primary_contact,
			int employee_secondary_contact, String employee_password_hash, boolean employee_active_status) {
		super();
		this.employee_id = employee_id;
		this.company_id = company_id;
		this.address = address;
		this.employee_date_of_birth = employee_date_of_birth;
		this.employee_age = employee_age;
		this.employee_aadhaar_number = employee_aadhaar_number;
		this.employee_emp_id = employee_emp_id;
		this.employee_salary = employee_salary;
		this.employee_joined_date = employee_joined_date;
		this.employee_first_name = employee_first_name;
		this.employee_middle_name = employee_middle_name;
		this.employee_last_name = employee_last_name;
		this.employee_email = employee_email;
		this.employee_primary_contact = employee_primary_contact;
		this.employee_secondary_contact = employee_secondary_contact;
		this.employee_password_hash = employee_password_hash;
		this.employee_active_status = employee_active_status;
	}
	
	

}
