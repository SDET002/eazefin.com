package com.example.springmvc.hello.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springmvc.hello.entity.Address;

public interface AddressRepository extends JpaRepository<Address, Integer> {

}
