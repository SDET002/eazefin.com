package com.example.springmvc.hello.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
//import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_address")
public class Address {


	@Id	
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int address_id;
	@Column
	private String address_name;
	@Column
	private String address_post_office;
	@Column
	private String address_city;
	@Column
	private String address_district;
	@Column
	private String address_state;
	@Column
	private String address_country;
	@Column
	private int address_zip;
	
	public int getAddress_id() {
		return address_id;
	}
	public void setAddress_id(int address_id) {
		this.address_id = address_id;
	}
	public String getAddress_name() {
		return address_name;
	}
	public void setAddress_name(String address_name) {
		this.address_name = address_name;
	}
	public String getAddress_post_office() {
		return address_post_office;
	}
	public void setAddress_post_office(String address_post_office) {
		this.address_post_office = address_post_office;
	}
	public String getAddress_city() {
		return address_city;
	}
	public void setAddress_city(String address_city) {
		this.address_city = address_city;
	}
	public String getAddress_district() {
		return address_district;
	}
	public void setAddress_district(String address_district) {
		this.address_district = address_district;
	}
	public String getAddress_state() {
		return address_state;
	}
	public void setAddress_state(String address_state) {
		this.address_state = address_state;
	}
	public String getAddress_country() {
		return address_country;
	}
	public void setAddress_country(String address_country) {
		this.address_country = address_country;
	}
	public int getAddress_zip() {
		return address_zip;
	}
	public void setAddress_zip(int address_zip) {
		this.address_zip = address_zip;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
