package com.example.springmvc_bhanu1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmvcBhanu1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
